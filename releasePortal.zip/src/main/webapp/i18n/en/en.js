import { all } from 'deepmerge';

export default all(Object.values(import.meta.glob('./*.json', { import: 'default', eager: true })));
