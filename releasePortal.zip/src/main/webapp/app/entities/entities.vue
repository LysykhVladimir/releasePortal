<template>
  <router-view></router-view>
</template>

<script lang="ts" src="./entities.component.ts"></script>
