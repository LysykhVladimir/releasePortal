<template>
  <div id="footer" class="footer">
    <p v-text="t$('footer')"></p>
  </div>
</template>

<script lang="ts" src="./jhi-footer.component.ts"></script>
