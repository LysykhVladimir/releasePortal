const languages = () => ({
  ru: { name: 'Русский' },
  en: { name: 'English' },
  // jhipster-needle-i18n-language-key-pipe - JHipster will add/remove languages in this object
});

export default languages;
