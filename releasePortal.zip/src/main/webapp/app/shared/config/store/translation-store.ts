import { defineStore } from 'pinia';

interface TranslationState {
  currentLanguage: string;
}

export const useTranslationStore = defineStore('translationStore', {
  state: (): TranslationState => ({
    currentLanguage: undefined,
  }),
  actions: {
    setCurrentLanguage(newLanguage) {
      this.currentLanguage = newLanguage;
      localStorage.setItem('currentLanguage', newLanguage);
    },
  },
});
