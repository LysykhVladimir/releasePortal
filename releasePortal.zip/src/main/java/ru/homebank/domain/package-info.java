/**
 * Domain objects.
 */
package ru.homebank.domain;
