/**
 * Application configuration.
 */
package ru.homebank.config;
