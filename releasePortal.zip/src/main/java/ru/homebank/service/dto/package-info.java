/**
 * Data transfer objects for rest mapping.
 */
package ru.homebank.service.dto;
