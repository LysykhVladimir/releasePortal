/**
 * Application security utilities.
 */
package ru.homebank.security;
