/**
 * Application management.
 */
package ru.homebank.management;
