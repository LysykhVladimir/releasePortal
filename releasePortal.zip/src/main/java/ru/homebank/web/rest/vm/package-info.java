/**
 * Rest layer visual models.
 */
package ru.homebank.web.rest.vm;
