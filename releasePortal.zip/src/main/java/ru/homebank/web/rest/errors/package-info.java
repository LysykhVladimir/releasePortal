/**
 * Rest layer error handling.
 */
package ru.homebank.web.rest.errors;
