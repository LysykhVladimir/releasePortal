/**
 * Rest layer.
 */
package ru.homebank.web.rest;
