/**
 * Logging aspect.
 */
package ru.homebank.aop.logging;
